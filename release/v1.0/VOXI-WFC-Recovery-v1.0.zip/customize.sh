#!/system/bin/sh

SKIPMOUNT=true
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

ui_print "*******************************"
ui_print " VOXI WFC Recovery v1.0"
ui_print "*******************************"

ABI="$(getprop ro.product.cpu.abi)"
case "$ABI" in
  arm64-v8a) ;;
  *) abort "Unsupported ABI: $ABI (arm64-v8a required)" ;;
esac

if [ -z "$MAGISK_VER" ] && [ -z "$MAGISK_VER_CODE" ]; then
  abort "Magisk environment not detected"
fi

for FILE in \
  module.prop \
  action.sh \
  bin/wfcctl.sh \
  lib/wfc-probe.jar \
  lib/wfc-recovery-helper.jar \
  README.md; do
  [ -f "$MODPATH/$FILE" ] || abort "Missing module file: $FILE"
done

mkdir -p /data/adb/voxi-wfc-recovery/logs
mkdir -p /data/adb/voxi-wfc-recovery/state
chmod 0700 /data/adb/voxi-wfc-recovery
chmod 0700 /data/adb/voxi-wfc-recovery/logs
chmod 0700 /data/adb/voxi-wfc-recovery/state

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/customize.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/bin/wfcctl.sh" 0 0 0755
set_perm "$MODPATH/lib/wfc-probe.jar" 0 0 0644
set_perm "$MODPATH/lib/wfc-recovery-helper.jar" 0 0 0644

ui_print "No boot service, daemon, property, or SELinux changes installed."
ui_print "Use the Magisk Action button or: su -c '<module>/bin/wfcctl.sh status'"
